﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Assignment4
{
    public class AgeRule:ValidationRule
    {
        int ageMin;
        int ageMax;
        public int AgeMin { get => ageMin; set => ageMin = value; }
        public int AgeMax { get => ageMax; set => ageMax = value; }

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            int numVal = 0;
            if (!int.TryParse(value.ToString(), out numVal))
            {
                return new ValidationResult(false, "invalid data");
            }
            if (numVal < AgeMin || numVal > AgeMax)
            {
                return new ValidationResult(false, "invalid age range");
            }

            return ValidationResult.ValidResult;
        }
    }
}
