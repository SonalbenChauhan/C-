﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace hairdresserShop
{
    [XmlRoot("AppointmentList")]
    public class AppointmentList : IEnumerable<Client>
    {
        [XmlArray("Appointments")]
        [XmlArrayItem("Client", typeof(Client))]
        private List<Client> appList = null;
        public List<Client> AppList { get => appList; set => appList = value; }
        public AppointmentList()

        {
            AppList = new List<Client>();

        }
        public void Add(Client a)
        {
            AppList.Add(a);
        }

        public IEnumerator<Client> GetEnumerator()
        {
            return ((IEnumerable<Client>)AppList).GetEnumerator();

        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return ((IEnumerable<Client>)AppList).GetEnumerator();

        }

        public int Count
        {
            get
            {
                return AppList.Count;
            }
        
           
        }


        public Client this[int i]
        {
            get { return AppList[i]; }
            set { AppList[i] = value;  }
        }

        public void Sort()
        {
            AppList.Sort();
        }
    }
}




